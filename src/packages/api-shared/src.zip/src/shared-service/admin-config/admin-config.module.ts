import { Module } from '@nestjs/common';
import { AdminConfigCache } from './admin-config.cache.js';
import { AdminConfigService } from './admin-config.service.js';
import { AdminConfigClient } from './redis-config.client.js';

@Module({
    providers: [AdminConfigService, AdminConfigCache, AdminConfigClient],
    exports: [AdminConfigService, AdminConfigCache],
})
export class AdminConfigModule {}
