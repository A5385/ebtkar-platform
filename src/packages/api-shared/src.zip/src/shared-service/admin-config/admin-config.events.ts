export const ADMIN_CONFIG_EVENTS = {
    UPDATED: 'admin.config.updated',
    SYNC: 'admin.config.sync',
};

export interface AdminConfigUpdatedEvent {
    eventId: string;
    scope: string;
    service?: string;
    version: number;
    updatedAt: string;
}
