import { Injectable } from '@nestjs/common';
import { AdminConfigCache } from './admin-config.cache.js';
import { AdminConfigClient } from './redis-config.client.js';

@Injectable()
export class AdminConfigService {
    constructor(
        private cache: AdminConfigCache,

        private client: AdminConfigClient,
    ) {}

    async load(service: string) {
        const config = await this.client.get(`config:${service}`);

        if (config) {
            this.cache.set(config);
        }
    }

    get() {
        return this.cache.get();
    }
}
