import { Injectable } from '@nestjs/common';
import { AdminConfig } from './admin-config.interface.js';

@Injectable()
export class AdminConfigCache {
    private config?: AdminConfig;

    set(config: AdminConfig) {
        this.config = config;
    }

    get(): AdminConfig {
        if (!this.config) {
            throw new Error('Admin configuration not loaded');
        }

        return this.config;
    }

    clear() {
        this.config = undefined;
    }
}
