import { Injectable } from '@nestjs/common';
import { RedisService } from '../redis/redis.service.js';
import { AdminConfig } from './admin-config.interface.js';

@Injectable()
export class AdminConfigClient {
    constructor(private readonly redis: RedisService) {}

    async get(key: string): Promise<AdminConfig | null> {
        return this.redis.get<AdminConfig>(key);
    }

    async set(key: string, config: AdminConfig): Promise<void> {
        await this.redis.set(key, config);
    }
}
