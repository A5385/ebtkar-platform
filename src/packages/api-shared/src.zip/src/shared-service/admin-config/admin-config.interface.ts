export type ConfigScope = 'GLOBAL' | 'SERVICE' | 'TENANT';

export interface AdminConfig {
    id?: string;
    scope: ConfigScope;
    service?: string;
    version: number;
    data: Record<string, unknown>;
    updatedAt?: Date;
}
// example data
// {
//  "scope":"SERVICE",
//  "service":"auth",
//  "version":3,
//  "data":{
//     "otpExpire":300,
//     "maxLoginAttempt":5
//  }
// }
